package restaurant;
import java.time.LocalDate;
import java.util.HashMap;

/**
 * Sales report in a given time period.
 *
 * @author owl
 * @author TODO
 * @version 0.0
 */
public class SalesReport {
    /**
     * Starting date.
     */
    private LocalDate from;

    /**
     * End date.
     */
    private LocalDate to;

    /**
     * Total revenue in the given time period.
     */
    private double totalRevenue;

    /**
     * Quantity of menu items sold.
     */
    private HashMap<MenuComponent, Integer> itemSoldTable;

    // TODO I'm too sleepy to write the interface now. Forgive me.
    // Basic idae: processOrder(order) function that automatically process an order
    // (add to total revenue, update sold quantity of individual item).
    // And a print() function.
}
